from PythonMusic.__main__ import custom_sound, wait, note, PythonMusic_help
